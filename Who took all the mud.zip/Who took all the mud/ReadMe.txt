Welcome to "Who took all the mud," a puzzle pack for The Golem. To play these levels,
you must download the level editor from http://www.fastram.co.uk/the_golem/designer/
and place these levels in the data folder.

Many of these puzzles are based on levels in The Golem, or earlier versions that existed during playtesting,
while others are more original.

I suggest solving these puzzles after completing the original game for two reasons:
one is that they may spoil some techniques that are better introduced in The Golem,
and two is that you've still got some good puzzles to finish, get cracking!

That said, the first puzzle is not too advanced and can be attempted after you solve "aim" in The Golem.

Here is a list of the nine puzzles roughly ordered by difficulty:
1 - Fluke
2 - Pigeonhole
3 - Less
4 - Least
5 - Crash
6 - Punless
7 - Wigwag
8 - Telekognosis
9 - Dethroned

Many thanks to Dom Camus! Actually my thanks can be enumerated:

For designing the brilliant The Golem
For playtesting several of the levels in this pack
For allowing me to steal ideas from his own levels, presumably

-Joel